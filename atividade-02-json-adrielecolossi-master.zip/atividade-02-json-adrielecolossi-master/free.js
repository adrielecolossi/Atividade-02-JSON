// tema: lançamentos de cinema(2019)

console.log('free.js');

const cinema = {
    meses: {
        total: 91,
        janeiro: {
            lancamentos: 14,
            classificacao: {
                animacao: [
                    {
                        titulo: 'Wifi Ralph Quebrando a Internet',
                        direcao: ['Rich Moore', 'Phil Johnston'],
                        info: 'Ralph, o mais famoso vilão dos videogames,'
                            + ' e Vanellope, sua companheira atrapalhada, '
                            + 'iniciam mais uma arriscada aventura. Após '
                            + 'a gloriosa vitória no Fliperama Litwak, a'
                            + ' dupla viaja para a world wide web, no '
                            + 'universo expansivo e desconhecido da '
                            + 'internet. Dessa vez, a missão é achar uma '
                            + 'peça reserva para salvar o videogame Corrida'
                            + ' Doce, de Vanellope. Para isso, eles contam'
                            + ' com a ajuda dos "cidadãos da Internet" e'
                            + ' de Yess, a alma por trás do "Buzzztube",'
                            + ' um famoso website que dita tendências.'
                    },
                    {
                        titulo: 'HOMEM-ARANHA NO ARANHAVERSO',
                        direcao: ['Peter Ramsey', 'Rodney Rothman',
                            'Bob Persichetti'],
                        info: 'Miles Morales é um jovem negro do Brooklyn que'
                            + ' se tornou o Homem-Aranha inspirado no legado'
                            + ' de Peter Parker, já falecido. Entretanto, ao'
                            + ' visitar o túmulo de seu ídolo em uma noite '
                            + 'chuvosa, ele é surpreendido com a presença do '
                            + 'próprio Peter, vestindo o traje do herói '
                            + 'aracnídeo sob um sobretudo. A surpresa fica '
                            + 'ainda maior quando Miles descobre que ele veio '
                            + 'de uma dimensão paralela, assim como outras '
                            + 'versões do Homem-Aranha.'
                    }
                ],
                documentario: [
                    {
                        titulo: 'Sou o carnaval',
                        direcao: 'Márcio Cavalcante',
                        info: 'Durante o carnaval em Salvador, a grande '
                            + 'mídia foca nos trios elétricos e camarotes '
                            + 'lotados por personalidades e artistas famosos.'
                            + ' No entanto, o diretor Marcio Cavalcante procuro'
                            + 'u conversar com pessoas anônimas, o povo, que sã'
                            + 'o fundamentais para compor a histeria coletiva'
                            + ' que sustenta o carnaval baiano há anos. Uma '
                            + 'pesquisa aprofundada sobre as origens da festa '
                            + 'popular que é reconhecida mundialmente pela '
                            + 'alegria e simpatia que reproduz durante os '
                            + 'quatro dias - ou mais - de duração.'
                    }
                ],
                drama: [
                    {
                        titulo: 'A ESPOSA',
                        direcao: 'Björn Runge',
                        info: 'Joan Castleman (Glenn Close) é casada com um'
                            + ' homem controlador e que não sabe como cuidar'
                            + ' de si mesmo ou de outra pessoa. Ele é um '
                            + 'escritor e está prestes a receber um Prêmio '
                            + 'Nobel de literatura. Joan, que passou 40 anos'
                            + ' ignorando seus talentos literários para '
                            + 'valorizar a carreira do marido, decide '
                            + 'abandoná-lo.'
                    },
                    {
                        titulo: 'A FAVORITA',
                        direcao: 'Yórgos Lánthimos',
                        info: 'Na Inglaterra do século XVIII, Sarah Churchill,'
                            + ' a Duquesa de Marlborough (Rachel Weisz) exerce'
                            + ' sua influência na corte como confidente, '
                            + 'conselheira e amante secreta da Rainha Ana '
                            + '(Olivia Colman). Seu posto privilegiado, no '
                            + 'entanto, é ameaçado pela chegada de Abigail '
                            + '(Emma Stone), nova criada que logo se torna a'
                            + ' queridinha da majestade e agarra com unhas e '
                            + 'dentes à oportunidade única.'
                    },
                    {
                        titulo: 'GREEN BOOK - O GUIA',
                        direcao: 'Peter Farrelly',
                        info: '1962. Tony Lip (Viggo Mortensen), um dos maior'
                            + 'es fanfarrões de Nova York, precisa de trabalho'
                            + ' após sua discoteca, o Copacabana, fechar as '
                            + 'portas. Ele conhece um um pianista e quer que '
                            + 'Lip faça uma turnê com ele. Enquanto os dois '
                            + 'se chocam no início, um vínculo finalmente '
                            + 'cresce à medida que eles viajam.'
                    },
                    {
                        titulo: 'CLIMAX',
                        direcao: 'Gaspar Noé',
                        info: 'Nos anos 90, um grupo de dançarinos urbanos '
                            + 'se reúnem em um isolado internato, localizado'
                            + ' no coração de uma floresta, para um importante'
                            + ' ensaio. Ao fazerem uma última festa de '
                            + 'comemoração, eles notam a atmosfera mudando e'
                            + ' percebem que foram drogados quando uma '
                            + 'estranha loucura toma conta deles. Sem saberem o'
                            + ' por quê ou por quem, os jovens mergulham num '
                            + 'turbilhão de paranoia e psicose. Enquanto para '
                            + 'uns, parece o paraíso, para outros parece uma '
                            + 'descida ao inferno.'
                    }
                ],
                comedia: [
                    {
                        titulo: 'UMA NOVA CHANCE',
                        direcao: 'Peter Segal',
                        info: 'Maya (Jennifer Lopez) é uma caixa de super'
                            + 'mercado insatisfeita com sua vida profissi'
                            + 'onal. Porém, tudo muda com uma pequena '
                            + 'alteração em seu currículo e suas redes '
                            + 'sociais. Com sua experiêcia das ruas, '
                            + 'habilidades excepcionais e a ajuda de seus'
                            + ' amigos, ela se reinventa e se torna uma '
                            + 'executiva de sucesso.'
                    },
                    {
                        titulo: 'Praça Pública',
                        direcao: 'Agnès Jaoui',
                        info: 'Castro (Jean-Pierre Bacri) costumava ser '
                            + 'um apresentador de TV de sucesso, mas sua '
                            + 'fama ficou no passado. Quando sua produtora,'
                            + ' Nathalie (Léa Drucker), se muda para o '
                            + 'interior, ele vai parar em uma festa de '
                            + 'abertura da casa junto com sua filha, sua ex'
                            + ' mulher, a atual namorada e uma porção de '
                            + 'excêntricos convidados'
                    }
                ],
                acao: [
                    {
                        titulo: 'DRAGON BALL SUPER BROLY',
                        direcao: 'Tatsuya Nagamine',
                        info: 'Apesar da Terra estar em um período de '
                            + 'calmaria, Goku se recusa a parar de treinar '
                            + 'constantemente - ele quer estar pronto para'
                            + ' quando uma nova ameaça surgir. O que ele '
                            + 'não imaginava era que seu novo inimigo seria'
                            + ' Broly, um poderoso super saiyajin sedento por'
                            + ' vingança, que deseja destruir todos que encon'
                            + 'trar pela frente.'
                    },
                    {
                        titulo: 'CREED II',
                        direcao: 'Steven Caple Jr.',
                        info: 'Adonis Creed (Michael B. Jordan) saiu mais '
                            + 'forte do que nunca de sua luta contra  Ricky Con'
                            + 'lan (Tony Bellew), e segue sua trajetória rumo '
                            + 'ao campeonato mundial de boxe, contra toda a '
                            + 'desconfiança que acompanha a sombra de seu pai '
                            + 'e com o apoio de Rocky (Sylvester Stallone). '
                            + 'Sua próxima luta não será tão simples,  '
                            + 'ele precisa enfrentar um adversário que possui '
                            + 'uma forte ligação com o passado de sua família,'
                            + ' o que torna tudo ainda mais complexo.'
                    }
                ],
                ficcaocientifica: [
                    {
                        titulo: 'MÁQUINAS MORTAIS',
                        direcao: 'Christian Rivers',
                        info: 'Anos depois da "Guerra dos Sessenta Minutos".'
                            + ' A Terra está destruída e para sobreviver as cid'
                            + 'ades se movem em rodas gigantes, conhecidas como'
                            + ' Cidades Tração, e lutam com outras para '
                            + 'conseguir mais recursos naturais. Quando Londres'
                            + ' se envolve em um ataque, Tom (Robert Sheehan) é'
                            + ' lançado para fora da cidade junto com uma fora'
                            + '-da-lei e os dois juntos precisam lutar para '
                            + 'sobreviver e ainda enfrentar uma ameaça que '
                            + 'coloca a vida no planeta em risco.'
                    }
                ],
                aventura: [
                    {
                        titulo: 'SHADE – ENTRE BRUXAS E HERÓIS',
                        direcao: 'Rasko Miljkovic',
                        info: 'Quieto e tímido, o jovem Jovan (Mihajlo Milavic)'
                            + ' nasceu com uma leve paralisia cerebral e '
                            + 'constantemente usa de sua imaginação para escapa'
                            + 'r da realidade na qual está inserido. Em sua '
                            + 'mente ele é um poderoso super-herói que combate'
                            + ' o crime de maneira corajosa e astuta, mas quand'
                            + 'o uma nova aluna se aproxima de Jovan querendo '
                            + 'uma amizade real, ele precisará fazer novas'
                            + ' escolhas.'
                    }
                ],
                suspense: [
                    {
                        titulo: 'VIDRO',
                        direcao: 'M. Night Shyamalan',
                        info: 'Após a conclusão de Fragmentado (2017), Kevin '
                            + 'Crumb (James McAvoy), o homem com 24 personalida'
                            + 'des diferentes, passa a ser perseguido por David'
                            + ' Dunn (Bruce Willis), o herói de Corpo Fechado '
                            + '(2000). O jogo de gato e rato entre o homem '
                            + 'inquebrável e a Fera é influenciado pela '
                            + 'presença de Elijah Price (Samuel L. Jackson), '
                            + 'que manipula seus encontros e guarda segredos '
                            + 'sobre os dois.'
                    }
                ]
            }
        },
        fevereiro: {
            lancamentos: 10,
            drama: [
                {
                    titulo: 'NORMANDIA NUA',
                    direcao: 'Philippe Le Guay',
                    info: 'Georges Balbuzard (François Cluzet) é o prefeito da'
                        + ' pequena cidade de Mêle sur Sarthe, na Normandia, '
                        + 'onde os agricultores vêm sofrendo cada vez mais por'
                        + ' conta de uma crise econômica. Quando o fotógrafo '
                        + 'Blake Newman (Toby Jones), conhecido por deixar '
                        + 'multidões nuas em suas obras, está passando pela '
                        + 'região, Balbuzard enxerga nisso uma oportunidade '
                        + 'perfeita para salvar seu povo. Só falta convencer '
                        + 'os cidadãos a tirarem a roupa.'
                },
                {
                    titulo: 'Guerra Fria',
                    direcao: 'Pawel Pawlikowski',
                    info: 'Durante a Guerra Fria entre a Polônia stalinista e'
                        + ' a Paris boêmia dos anos 50, um músico amante da '
                        + 'liberdade e uma jovem cantora com histórias e '
                        + 'temperamentos completamente diferentes vivem um'
                        + ' amor impossível.'
                },
                {
                    titulo: 'A Caminho de Casa',
                    direcao: 'Charles Martin Smith',
                    info: 'Bella é uma cadelinha especial que vive com Lucas'
                        + ', um estudante de medicina veterinária que trabalha'
                        + ' como voluntário em um hospital local. Um dia ela é'
                        + ' encontrada pelo Controle de Animais na rua e acaba'
                        + ' sendo levada para um abrigo a 400 milhas de '
                        + 'distância de seu dono. No entanto, Bella, uma '
                        + 'cachorra extremamente leal e corajosa, decide '
                        + 'iniciar sozinha uma longa jornada de volta para a '
                        + 'casa, emocionando a todos que cruzam o seu caminho.'
                }
            ],
            animacao: [
                {
                    titulo: 'UMA AVENTURA LEGO 2',
                    direcao: 'Mike Mitchell (V)',
                    info: 'Cinco anos após os eventos do primeiro filme, a '
                        + 'batalha contra inimigos alienígenas faz com que a'
                        + ' cidade Lego torne-se Apocalipsópolis, em um '
                        + 'futuro distópico onde nada mais é incrível. Neste'
                        + ' contexto, Emmet constrói uma casa para que possa'
                        + ' viver ao lado de Lucy, mas ela ainda o considera '
                        + 'ingênuo demais. Quando um novo ataque captura não '
                        + 'apenas Lucy, mas também Batman, Astronauta, '
                        + 'UniKitty e o pirata, levando-os ao sistema '
                        + 'planetário de Manar, cabe a Emmet construir uma '
                        + 'espaçonave e partir em seu encalço. No caminho ele'
                        + ' encontra Rex Perigoso, um navegante solitário que'
                        + ' decide ajudá-lo em sua jornada.'
                }
            ],
            comedia: [
                {
                    titulo: 'O GALÃ',
                    direcao: 'Francisco Ramalho Jr.',
                    info: 'Júlio (Thiago Fragoso) aspira se tornar um grande '
                        + 'ator, mas a grande maioria de suas empreitadas nas'
                        + ' telas costumam dar errado. Quando o dinheiro aperta'
                        + ', ele resolve recorrer ao seu meio irmão Beto (Luiz'
                        + ' Henrique Nogueira), um obcecado roteirista de novel'
                        + ' que vive em reclusão, com quem ele não tem muito '
                        + 'contato. O ator acredita que sua grande chance será '
                        + 'concedida pelo irmão, mas a relação entre os dois se'
                        + ' torna a cada dia mais insustentável. '
                },
                {
                    titulo: 'PODERIA ME PERDOAR?',
                    direcao: 'Marielle Heller',
                    info: 'Passando por problemas financeiros, a jornalista Lee'
                        + ' Israel decide forjar e vender cartas de personalida'
                        + 'des já falecidas, um negócio criminoso que dá muito '
                        + 'certo. Quando as primeiras suspeitas começam, para '
                        + 'não parar de lucrar, ela modifica o esquema e passa'
                        + ' a roubar os textos originais de arquivos e biblio'
                        + 'tecas. Baseado em uma história real.'
                },
                {
                    titulo: 'SAI DE BAIXO - O FILME',
                    direcao: 'Cris DAmato',
                    info: 'É a volta dos personagens icônicos da série de suce'
                        + 'sso da Rede Globo, como Caco (Miguel Falabella), '
                        + 'Magda (Marisa Orth) e Ribamar (Tom Cavalcante), '
                        + 'assim como novos personagens que vão acrescentar'
                        + ' à bagunça.'
                },
                {
                    titulo: 'CHORAR DE RIR',
                    direcao: 'Toniko Melo',
                    info: '“Estrela do programa de TV Chorar de Rir” , Nilo'
                        + ' Perequê (Leandro Hassum) é um grande nome da '
                        + 'comédia no país. Quando ganha o prêmio de melhor'
                        + ' comediante do ano, o humorista decide mudar '
                        + 'radicalmente sua carreira e se dedicar totalmente'
                        + ' ao drama, deixando sua família e seu empresário '
                        + 'desesperados.'
                }
            ],
            terror: [
                {
                    titulo: 'A MORTE TE DÁ PARABÉNS 2',
                    direcao: 'Christopher Landon',
                    info: 'Depois de morrer diversas vezes para quebrar o feiti'
                        + 'ço temporal que a mantinha presa no dia de seu '
                        + 'aniversário, Tree Gelbman (Jessica Rothe) olha '
                        + 'para o futuro, tentando escrever uma nova história'
                        + ' ao lado de Carter (Israel Broussard). No entanto,'
                        + ' quando um experimento científico dá errado, a '
                        + 'jovem é forçada a retornar ao fluxo de repetição e,'
                        + ' desta vez, morrer não será o bastante para escapar.'
                }
            ],
            documentario: [
                {
                    titulo: 'LEMBRO MAIS DOS CORVOS',
                    direcao: 'Gustavo Vinagre',
                    info: 'Durante uma crise de insônia, a atriz Julia Katha'
                        + 'rine, uma mulher transexual, conta a história de'
                        + ' sua vida através de um monólogo. A intimidade da'
                        + ' personagem central é exposta através de relatos'
                        + ' reais de resistência e autoaceitação.'
                }
            ]
        },
        marco: {
            lancamentos: 6,
            classificacao: {
                acao: [
                    {
                        titulo: 'Capitã Marvel',
                        direcao: 'Anna Boden, Ryan Fleck',
                        info: 'Carol Danvers (Brie Larson) é uma ex-agente da '
                            + 'Força Aérea norte-americana, que, sem se '
                            + 'lembrar de sua vida na Terra, é recrutada pelos'
                            + ' Kree para fazer parte de seu exército de elite.'
                            + ' Inimiga declarada dos Skrull, ela acaba voltand'
                            + 'o ao seu planeta de origem para impedir uma '
                            + 'invasão dos metaformos, e assim vai acabar '
                            + 'descobrindo a verdade sobre si, com a ajuda do'
                            + ' agente Nick Fury (Samuel L. Jackson) e da '
                            + 'gata Goose.'
                    },
                    {
                        titulo: 'RAIVA',
                        direcao: 'Sérgio Tréfaut',
                        info: 'Nos remotos campos do Baixo Alentejo, no sul de '
                            + 'Portugal, a miséria e a fome assolam a população'
                            + '. Quando dois violentos assassinatos acontecem '
                            + 'em uma só noite, um mistério toma o lugar: qual '
                            + 'poderia ser a origem desses crimes?'
                    }
                ],
                comedia: [
                    {
                        titulo: 'O rei de roma',
                        direcao: 'Daniele Luchetti',
                        info: 'Numa Tempesta (Marco Giallini) é um focado e '
                            + 'carismático homem de negócios que, levado por '
                            + 'uma gigante necessidade de ser bem sucedido, faz'
                            + ' qualquer coisa para fechar um negócio, mesmo '
                            + 'que isso o leve a infrigir a lei. Depois de uma'
                            + ' negociação dar errado, ele é pego pela polícia'
                            + ' e condenado a um ano de prisão domicilar, mas '
                            + 'agora fará de qualquer coisa para voltar a '
                            + 'trabalhar normalmente.'
                    }
                ],
                suspense: [
                    {
                        titulo: 'Nós',
                        direcao: 'Jordan Peele',
                        info: 'Adelaide (Lupita Nyongo) e Gabe(Winston Duke) '
                            + 'decidem levar a família para passar um fim de '
                            + 'semana na praia e descansar em uma casa de '
                            + 'veraneio.Eles viajam com os filhos e começam a'
                            + 'aproveitar o ensolarado local, mas a chegada de'
                            + ' um grupo misterioso muda tudo e a família se '
                            + 'torna refém de seus próprios duplos.'
                    },
                    {
                        titulo: 'A REBELIÃO',
                        direcao: 'Rupert Wyatt',
                        info: 'Em um bairro de Chicago, quase uma década após '
                            + 'uma invasão alienígena no planeta Terra, '
                            + 'acompanhamos como é a vida das pessoas nos dois'
                            + ' lados do conflito, o dos colaboradores e o dos'
                            + ' dissidentes.'
                    }
                ],
                aventura: [
                    {
                        titulo: 'Dumbo',
                        direcao: 'Tim Burton',
                        info: 'Holt Farrier (Colin Farrell) é uma ex-estrela '
                            + 'de circo que, ao retornar da Primeira Guerra '
                            + 'Mundial, encontra seu mundo virado de cabeça '
                            + 'para baixo. Além de perder um braço no front, '
                            + 'sua esposa faleceu enquanto estava fora e ele '
                            + 'agora precisa criar os dois filhos. Soma-se a '
                            + 'isso o fato de ter perdido seu antigo posto no '
                            + 'circo, sendo agora o encarregado em cuidar de '
                            + 'uma elefanta que está prestes a parir. Quando o'
                            + ' bebê nasce, todos ficam surpresos com o tamanho'
                            + ' de suas orelhas, o que faz com que de início '
                            + 'seja desprezado. Cabe então aos filhos de Holt '
                            + 'a tarefa de cuidar do pequenino, até que eles '
                            + 'descobrem que as imensas orelhas permitem que '
                            + 'Dumbo voe.'
                    }
                ]
            }
        },
        abril: {
            lancamentos: 4,
            classificacao: {
                animacao: [
                    {
                        titulo: 'TRÊS FACES',
                        direcao: 'Jafar Panahi',
                        info: 'Uma famosa atriz iraniana recebe um vídeo '
                            + 'perturbador de uma garota implorando por '
                            + 'ajuda para escapar de sua família conservadora.'
                            + ' Ela então pede seu amigo, o diretor Jafar Pana'
                            + 'hi, para descobrir se o vídeo é real ou uma'
                            + ' manipulação. Juntos, eles seguem o caminho '
                            + 'para a aldeia da menina nas remotas montanhas do'
                            + ' norte, onde as tradições ancestrais continuam a'
                            + ' ditar a vida local.'
                    }
                ],
                drama: [
                    {
                        titulo: 'PRIMEIRO ANO',
                        direcao: 'Thomas Lilti',
                        info: 'Benjamin (William Lebghil) acaba de se formar no'
                            + ' ensino médio e está começando seu primeiro ano '
                            + 'da faculdade de medicina. Já Antoine (Vincent '
                            + 'Lacoste) está começando o primeiro ano pela '
                            + 'terceira vez. Quando os dois se conhecem, uma '
                            + ' amizade logo se forma e os dois se unem para '
                            + 'enfrentar noites mal dormidas, um ambiente  '
                            + 'extremamente competitivo e a pressão das '
                            + 'expectativas para seu futuro.'
                    }
                ],
                acao: [
                    {
                        titulo: 'SHAZAM!',
                        direcao: 'David F. Sandberg',
                        info: 'Billy Batson (Asher Angel) tem apenas 14 anos '
                            + 'de idade, mas recebeu de um antigo mago o dom'
                            + ' de se transformar num super-herói adulto '
                            + 'chamado Shazam (Zachary Levi). Ao gritar a '
                            + 'palavra SHAZAM!, o adolescente se transforma '
                            + 'nessa sua poderosa versão adulta para se '
                            + 'divertir e testar suas habilidades. Contudo, '
                            + 'ele precisa aprender a controlar seus poderes'
                            + ' para enfrentar o malvado Dr. Thaddeus Sivana'
                            + ' (Mark Strong).'
                    },
                    {
                        titulo: 'Vingadores - Ultimato',
                        direcao: ['Joe Russo', 'Anthony Russo'],
                        info: 'Após Thanos eliminar metade das criaturas '
                            + 'vivas, os Vingadores precisam lidar com a dor '
                            + 'da perda de amigos e seus entes queridos. Com '
                            + 'Tony Stark (Robert Downey Jr.) vagando perdido '
                            + 'no espaço sem água nem comida, Steve Rogers '
                            + '(Chris Evans) e Natasha Romanov (Scarlett '
                            + 'Johansson) precisam liderar a resistência '
                            + 'contra o titã louco.'
                    }
                ]
            }
        },
        maio: {
            lancamentos: 6,
            classificacao: {
                ficcaocientifica: [
                    {
                        titulo: 'AD ASTRA',
                        direcao: ' James Gray',
                        info: 'Roy McBride (Brad Pitt) é um engenheiro '
                            + 'espacial, portador de um leve grau de autismo'
                            + ', que decide empreender a maior jornada de sua'
                            + ' vida: viajar para o espaço, cruzar a galáxia'
                            + ' e tentar descobrir o que aconteceu com seu '
                            + 'pai, um astronauta que se perdeu há vinte anos'
                            + ' atrás no caminho para Netuno.'
                    }
                ],
                acao: [
                    {
                        titulo: 'HELLBOY',
                        direcao: 'Neil Marshall',
                        info: 'Nova versão da série de filmes sobre Hellboy,'
                            + ' um ser de visual diabólico resultado do '
                            + 'relacionamento entre um demônio e uma temida'
                            + ' feiticeira. A sinopse oficial ainda não foi'
                            + ' divulgada.'
                    },
                    {
                        titulo: 'POKÉMON: DETETIVE PIKACHU',
                        direcao: 'Rob Letterman',
                        info: 'A trama será baseada no jogo Detective Pikachu,'
                            + ' que traz o pokémon elétrico resolvendo  '
                            + 'mistérios.'
                    },
                    {
                        titulo: 'GODZILLA II: REI DOS MONSTROS',
                        direcao: 'Michael Dougherty',
                        info: 'Sequência do longa-metragem lançado em 2014,'
                            + ' que trouxe de volta o famoso monstro japonês '
                            + 'para as telonas.'
                    }
                ],
                terror: [
                    {
                        titulo: 'CEMITÉRIO MALDITO',
                        direcao: ['Kevin Kölsch', 'Dennis Widmyer'],
                        info: 'Uma família se muda para uma nova casa, '
                            + 'localizada nos arredores de um antigo cemitério'
                            + ' amaldiçoado, usado para enterrar animais de '
                            + 'estimação, mas que já foi usado para sepultament'
                            + 'o de indígenas. Algumas coisas estranhas começam'
                            + ' a acontecer, transformando a vida cotidiana dos'
                            + ' moradores em um pesadelo'
                    }
                ],
                fantasia: [
                    {
                        titulo: 'ALADDIN',
                        direcao: 'Guy Ritchie',
                        info: 'Um jovem humilde descobre uma lâmpada mágica, '
                            + 'com um gênio que pode lhe conceder desejos. Agor'
                            + 'a o rapaz quer conquistar a moça por quem se '
                            + 'apaixonou, mas o que ele não sabe é que a jovem'
                            + ' é uma princesa que está prestes a se noivar. '
                            + 'Agora, com a ajuda do Gênio (Will Smith), ele '
                            + 'tenta se passar por um príncipe e para '
                            + 'conquistar o amor da moça e a confiança de seu'
                            + ' pai. A sinopse oficial ainda não foi divulgada.'
                    }
                ]
            }
        },
        junho: {
            lancamento: 5,
            classificacao: {
                aventura: [
                    {
                        titulo: 'Turma da Mônica Laços',
                        direcao: 'Daniel Rezende',
                        info: 'Floquinho, o cachorro do Cebolinha, desapareceu.'
                            + ' O menino desenvolve então um plano infalível '
                            + 'para resgatar o cãozinho, mas para isso vai '
                            + 'precisar da ajuda de seus fiéis amigos Mônica,'
                            + ' Magali e Cascão. Juntos, eles irão enfrentar'
                            + ' grandes desafios e viver grandes aventuras '
                            + 'para levar o cão de volta para casa. '
                    }
                ],
                terror: [
                    {
                        titulo: 'Annabelle 3',
                        direcao: 'Gary Dauberman',
                        info: 'Quando Ed (Patrick Wilson) e Lorraine Warren '
                            + ' (Vera Farmiga) deixam sua casa durante um fim '
                            + 'de semana, a filha do casal, a pequena Judy'
                            + ' Warren (McKenna Grace), é deixada aos cuidados'
                            + ' de sua babá (Madison Iseman). Mas as duas '
                            + 'entram em perigo quando a maligna boneca'
                            + ' Annabelle, aproveitando que os investigadores'
                            + ' paranormais estão fora de jogo, anima os letais'
                            + ' e aterrorizantes objetos contidos na Sala dos'
                            + ' Artefatos dos Warren.'
                    }
                ],
                drama: [
                    {
                        titulo: 'EU NÃO SOU UMA BRUXA',
                        direcao: 'Rungano Nyoni',
                        info: 'Depois de um incidente banal em sua vila, a'
                            + ' menina de 8 anos Shula (Maggie Mulubwa) é acusa'
                            + 'da de bruxaria. Depois de um rápido julgamento,'
                            + ' a garota se torna culpada e é levada em custódi'
                            + 'a pelo Estado, sendo exilada para um campo de'
                            + ' bruxas no meio do deserto. No local, ela passa'
                            + ' por uma cerimônia de iniciação em que aprende '
                            + 'as regras da sua nova vida como bruxa. Como as '
                            + 'outras residentes, ela é amarrada em uma grande '
                            + 'árvore, sendo ameaçada de ser amaldiçoada e de '
                            + 'se transformar em uma cabra caso corte a fita.'
                    }
                ],
                animacao: [
                    {
                        titulo: 'PETS - A VIDA SECRETA DOS BICHOS 2',
                        direcao: 'Chris Renaud',
                        info: 'Sequência da animação "Pets - A Vida Secreta '
                            + 'dos Bichos".'
                    },
                    {
                        titulo: 'TOY STORY 4',
                        direcao: 'Josh Cooley',
                        info: 'Agora morando na casa da pequena Bonnie, Woody'
                            + ' apresenta aos amigos o novo brinquedo construíd'
                            + 'do por ela: Forky, baseado em um garfo de '
                            + 'verdade. O novo posto de brinquedo não o agrada'
                            + ' nem um pouco, o que faz com que Forky fuja de'
                            + ' casa. Decidido a trazer de volta o atual '
                            + 'brinquedo favorito de Bonnie, Woody parte em '
                            + 'seu encalço e, no caminho, reencontra Bo Peep,'
                            + ' que agora vive em um parque de diversões.'
                    }
                ]
            }
        },
        julho: {
            lancamentos: 7,
            classificacao: {
                drama: [
                    {
                        titulo: 'Em guerra',
                        direcao: ' Stéphane Brizé',
                        info: 'A administração da fábrica Perrin Industrie'
                            + ' decide pelo fechamento total da empresa. '
                            + 'Tendo o acordo feito dois anos antes desprezado'
                            + ' e as promessas não respeitadas, os 1100 '
                            + 'funcionários, liderados por seu porta-voz '
                            + 'Laurent Amedeo (Vincent Lindon), recusam esta'
                            + ' decisão brutal e vão fazer de tudo para salvar'
                            + ' seus empregos.'
                    }
                ],
                documentario: [
                    {
                        titulo: 'A delicadeza é azul',
                        direcao: 'Yasmin Garcez',
                        info: 'Oferecendo uma outra perspectiva para a rotina'
                            + ' das pessoas que vivem com o autismo, pais, '
                            + 'professores, assistentes sociais e crianças '
                            + 'explicam, em suas próprias visões, como enxergam'
                            + ' a vida. Das questões sensoriais até educacionai'
                            + 'is todo o cenário daqueles que lidam com a '
                            + 'questão é analisado por uma ótica social'
                            + ' externa.'
                    }
                ],
                acao: [
                    {
                        titulo: 'Homem Aranha: De volta ao lar 2',
                        direcao: 'Jon Watts',
                        info: 'Peter Parker (Tom Holland) está em uma viagem de'
                            + ' duas semanas pela Europa, ao lado de seus '
                            + 'amigos de colégio, quando é surpreendido pela'
                            + 'visita de Nick Fury (Samuel L. Jackson).  '
                            + 'Convocado para mais uma missão heróica, ele '
                            + 'precisa enfrentar vários vilões que surgem em '
                            + 'cidades-símbolo do continente, como Londres, '
                            + 'Paris e Veneza, e também a aparição do'
                            + ' enigmático Mysterio (Jake Gyllenhaal).'
                    }
                ],
                aventura: [
                    {
                        titulo: 'O rei leão',
                        direcao: 'Jon Favreau',
                        info: 'Simba (Donald Glover) é um jovem leão cujo '
                            + 'destino é se tornar o rei da selva. Tudo '
                            + 'corre bem, até que uma grande tragédia atinge'
                            + ' sua vida mudando sua trajetória para sempre.'
                            + ' A sinopse oficial ainda não foi divulgada.'
                    },
                    {
                        titulo: 'A pequena Travessa',
                        direcao: 'Joachim Masannek',
                        info: 'Lilli Susewind (Malu Leicher) tem a '
                            + 'habilidade de falar com animais, mas fora seus'
                            + ' pais e sua avó, ninguém sabe deste segredo. '
                            + 'Quando ela conhece Jess (Aaron Kissiov), um '
                            + 'menino divertido e misterioso, decide contar '
                            + 'para ele. Juntos, os dois precisam achar o '
                            + 'filhote de elefante que foi roubado do '
                            + 'zoológico.'
                    }
                ],
                romance: [
                    {
                        titulo: 'Um homem fiel',
                        direcao: 'Direção: Louis Garrel',
                        info: 'Nove anos depois de deixá-lo pelo seu melhor '
                            + 'amigo, a agora viúva Marianne (Laetitia Casta)'
                            + ' volta para o jornalista Abel (Louis Garrel). '
                            + 'Porém, o que parece um belo recomeço logo se '
                            + 'mostra bem mais complicado e Abel se vê enrolado'
                            + ' em um monte de drama, como as maquinações do '
                            + 'estranho filho de Marianne e a questão de afinal'
                            + ' o que aconteceu com o ex marido dela.'
                    }
                ],
                terror: [
                    {
                        titulo: 'Crawl',
                        direcao: 'Alexandre Aja',
                        info: 'Uma jovem mulher tenta salvar o pai depois de um'
                            + ' terremoto, mas acaba ficando presa dentro de um'
                            + 'a casa durante uma enchente junto com os mais ' +
                            'selvagens predadores da Flórida. '
                    }
                ]
            }
        },
        agosto: {
            lancamentos: 13,
            classificacao: {
                comedia: [
                    {
                        titulo: 'Stuber',
                        direcao: 'Michael Dowse',
                        info: 'Quando Stu (Kumail Nanjiani), um motorista'
                            + ' da Uber, é recrutado por um policial (Dave'
                            + ' Bautista) para ajudá-lo a investigar o '
                            + 'paradeiro de um brutal assassino, algumas '
                            + 'regras precisam ser quebradas. Seguindo as '
                            + 'poucas pistas que possuem para seguir o traço'
                            + ' do criminoso, eles cada vez se complicam mais'
                            + ' na perseguição desenfreada.'
                    },
                    {
                        titulo: 'Era uma vez em...Hollywood',
                        direcao: 'Quentin Tarantino',
                        info: 'Um ator de televisão e seu dublê embarcaram '
                            + 'em uma odisséia para se fazer um nome para '
                            + 'si na indústria cinematográfica durante os'
                            + ' assassinatos de Charles Manson em 1969, na'
                            + ' cidade de Los Angeles. A sinopse oficial '
                            + 'ainda não foi divulgada.'
                    },
                    {
                        titulo: 'A chefinha',
                        direcao: 'Tina Gordon Chism',
                        info: 'Saturada e cansada de sua rotineira vida '
                            + 'adulta, uma mulher de meia-idade ganha a '
                            + 'oportunidade mágica de voltar no tempo e ser '
                            + 'jovem novamente. Vendo-se finalmente livre de'
                            + ' todas as responsabilidades, ela logo aprende'
                            + ' que até mesmo a jovialidade cobra o seu preço.'
                    }
                ],
                fantasia: [
                    {
                        titulo: 'OS NOVOS MUTANTES',
                        direcao: 'Josh Boone',
                        info: 'Cinco jovens mutantes descobrem o alcance de '
                            + 'seus poderes e lidam com traumas do passado '
                            + 'enquanto são mantidos presos contra a vontade'
                            + ' num sinistro hospital'
                    },
                    {
                        titulo: 'Artemis Fowl',
                        direcao: 'Kenneth Branagh',
                        info: 'Artemis Fowl é um garoto de 12 anos extremamente'
                            + ' inteligente que usa sua capacidade para roubar.'
                            + ' Um dia, ele descobre um local mágico chamado '
                            + 'mundo das fadas. Decidido a roubar a fortuna loc'
                            + 'al, ele sequestra um elfo e cobra um resgate '
                            + 'para libertá-lo. Só que logo a Liga de Elite da '
                            + 'Polícia parte em seu encalço.'
                    }
                ],
                acao: [
                    {
                        titulo: 'VELOZES & FURIOSOS: HOBBS & SHAW',
                        direcao: 'David Leitch',
                        info: 'Filme derivado da franquia Velozes & Furiosos, '
                            + 'focado nos personagens Luke Hobbs (Dwayne '
                            + 'Johnson), policial carrancudo e que sempre busca'
                            + ' a justiça, e Deckard Shaw (Jason Statham), um '
                            + 'assassino.'
                    },
                    {
                        titulo: 'Boss Level',
                        direcao: 'Joe Carnahan',
                        info: 'Um oficial da polícia aposentado inexplicavelmen'
                            + 'te fica preso no tempo e é obrigado a vivenciar '
                            + 'repetidamente o dia de sua morte. Enquanto tenta'
                            + ' evitar ser morto, ele percebe que existe uma '
                            + 'razão maior para que tudo isso aconteça.'
                    },
                    {
                        titulo: 'Angel has fallen',
                        direcao: 'Ric Roman Waugh',
                        info: 'Dedicado e sempre focado em seu trabalho, o agen'
                            + 'te do Serviço Secreto, Mike Banning (Gerard '
                            + 'Butler) vê sua vida mudar completamente da noite'
                            + ' para o dia ao ser acusado de conspirar para o '
                            + 'assassinato do presidente dos Estados Unidos. '
                            + 'Quando percebe que todos estão atrás dele, Mike '
                            + 'corre contra o tempo para descobrir o que '
                            + 'realmente aconteceu enquanto foge de outros '
                            + 'agentes.'
                    }
                ],
                drama: [
                    {
                        titulo: 'Jovens Polacas',
                        direcao: 'Alex Levy-Heller',
                        info: 'Depois de meses de pesquisa, o jovem jornalista '
                            + 'Ricardo (Emilio Orciollo Netto) finalmente chega'
                            + ' na fase final de sua pesquisa de doutorado a '
                            + 'respeito das escravas brancas no Rio de Janeiro,'
                            + ' também conhecidas como Polacas. Traficadas do '
                            + 'leste europeu para o Brasil, as jovens judias '
                            + 'eram levadas a acreditar que se casariam, até '
                            + 'serem levadas direto para prostíbulos. '
                    },
                    {
                        titulo: 'Hebe',
                        direcao: 'Mauricio Farias',
                        info: 'Hebe Camargo (Andréa Beltrão) se consagrou como '
                            + 'uma das apresentadoras mais emblemáticas da tele'
                            + 'visão brasileira. Sua carreira passou por divers'
                            + 'as mudanças ao longo dos anos, mas foi durante a'
                            + ' década de 80, no período de transição da '
                            + 'ditadura para a democracia, que Hebe, ao 60 anos'
                            + ', tomou uma decisão importante. A apresentadora'
                            + ' passou a controlar a própria carreira e, '
                            + 'independentemente das críticas machistas, do '
                            + 'marido ciumento e dos chefes poderosos, se '
                            + 'revelou para o público como uma mulher '
                            + 'extraordinária, capaz de superar qualquer crise'
                            + ' pessoal ou profissional.'
                    },
                    {
                        titulo: 'Simonal',
                        direcao: 'Leonardo Domingues',
                        info: 'Dono de voz marcante, carisma encantador e charm'
                            + 'e irresistível, Wilson Simonal (Fabrício '
                            + 'Boliveira) nasceu para ser uma das maiores vozes'
                            + ' de todos os tempos da música brasileira. No '
                            + 'entanto, após anos de sucesso conquistado com '
                            + 'muito trabalho, suas finanças descontroladas o '
                            + 'levam a, num rompante de ignorância, tomar '
                            + 'decisões que marcarão para sempre sua carreira.'
                    }
                ],
                aventura: [
                    {
                        titulo: 'Dora e a cidade perdida',
                        direcao: 'James Bobin',
                        info: 'As aventuras de Dora (Isabela Moner) junto com o'
                            + ' seu macaco Botas e a sua mochila falante. Os '
                            + 'anos se passaram e novas responsabilidades '
                            + 'surgiram na vida de Dora, agora ela frequenta a '
                            + 'escola e mora na cidade junto com o seu primo '
                            + 'Diego (Micke Moreno). No entanto, ela precisará'
                            + ' embarcar em uma nova aventura para salvar seus '
                            + 'pais e resolver o mistério de uma antiga '
                            + 'civilização perdida.'
                    },
                    {
                        titulo: 'Playmobil',
                        direcao: 'Lino DiSalvo',
                        info: 'Filme com os bonecos Playmobil!'
                    }
                ]
            }
        },
        setembro: {
            lancamentos: 7,
            classificacao: {
                terror: [
                    {
                        titulo: 'Medo profundo 2',
                        direcao: 'Johannes Roberts',
                        info: 'Um grupo de cinco amigas aventureiras viaja até '
                            + 'Recife, região nordeste do Brasil, para conhecer'
                            + ' as ruínas de uma cidade subaquática, no litoral'
                            + ' da cidade. No entanto, durante o passeio pelo '
                            + 'fundo do mar, elas descobrem que não estão sozin'
                            + 'has e os verdadeiros "moradores" do local não '
                            + 'estão muito satisfeitos com as visitas. '
                    },
                    {
                        titulo: 'IT: A COISA - CAPÍTULO 2',
                        direcao: 'Andy Muschietti',
                        info: '27 anos depois dos eventos de "It - Parte 1", o '
                            + 'grupo de adolescentes que fazia parte do "Losers'
                            + ' Club" - o clube dos perdedores - realiza uma '
                            + 'reunião. No entanto, o que parece ser apenas um'
                            + ' reencontro de velhos amigos acaba se tornando '
                            + 'em uma verdadeira e sangrenta batalha quando '
                            + 'Pennywise (Bill Skarsgard), o palhaço retorna.'
                    }
                ],
                comedia: [
                    {
                        titulo: 'Cadê você, Bernadette?',
                        direcao: 'Richard Linklater',
                        info: 'Antes de viajar com sua família para a Antártica'
                            + ', uma arquiteta que sofre de agorafobia - o medo'
                            + ' de estar em lugares abertos ou em meio à '
                            + 'multidões - some sem deixar pistas para trás. '
                            + 'Sua filha, então, através de emails, sessões com'
                            + ' sua psicóloga, cartas e outros documentos, tent'
                            + 'a descobrir para onde sua mãe foi e quais foram '
                            + 'as razões de seu desaparecimento.'
                    },
                    {
                        titulo: 'Um espião animal',
                        direcao: ['Nick Bruno', 'Troy Quane'],
                        info: 'Quando um evento inesperado acontece, Lance '
                            + 'Sterling (voz de Will Smith), o melhor espião do'
                            + ' mundo, precisa unir forças com o inventor Walte'
                            + 'r (voz de Tom Holland) para salvar o dia.'
                    }
                ],
                drama: [
                    {
                        titulo: 'A arte de correr na chuva',
                        direcao: 'Simon Curtis',
                        info: 'A história gira ao redor de um cachorro muito '
                            + 'inteligente, que passa os dias filosofando e apr'
                            + 'endendo o que é ser humano - a partir das observ'
                            + 'ações faz sobre a vida de seu dono, o piloto'
                            + ' Denny Swift (Milo Ventimiglia).'
                    }
                ],
                animacao: [
                    {
                        titulo: 'Abominável',
                        direcao: ['Jill Culton', 'Todd Wilderman'],
                        info: 'Durante uma viagem ao Himalaia, um grupo de '
                            + 'pessoas humildes encontra Everest, um Yeti, popu'
                            + 'larmente conhecido por sua altura extraordinária'
                            + ' e por viver escondido entre as incríveis '
                            + 'paisagens do sul da Ásia. Agora, os viajantes '
                            + 'precisam ajudar Everest na sua jornada de volta'
                            + ' para casa. A sinopse oficial ainda não foi'
                            + ' divulgada.'
                    }
                ],
                acao: [
                    {
                        titulo: 'A caça',
                        direcao: 'Craig Zobel',
                        info: 'Na intenção de fazer justiça com as próprias mão'
                            + 's, dois grupos completamente opostos iniciam uma'
                            + ' guerra armada que lentamente aumenta de '
                            + 'proporção trazendo consequências irreversíveis e'
                            + 'dividindo vez mais os cidadãos de uma pequena '
                            + 'vila.'
                    }
                ]
            }
        },
        outubro: {
            lancamentos: 9,
            classificacao: {
                acao: [
                    {
                        titulo: 'Coringa',
                        direcao: 'Todd Phillips',
                        info: 'História de origem do vilão mais conhecido e'
                            + ' insano já enfrentado pelo Batman: o lendário '
                            + 'Coringa (Joaquin Phoenix). A sinopse oficial'
                            + ' ainda não foi divulgada.'
                    },
                    {
                        titulo: 'Gemini Man',
                        direcao: 'Ang Lee',
                        info: 'O melhor assassino do mundo está ficando velho'
                            + ' e menos confiável. Por isso seus chefes '
                            + 'decidem eliminá-lo criando um clone mais novo'
                            + ' e mais forte com a tarefa de exterminá-lo. A '
                            + 'sinopse oficial ainda não foi divulgada.'
                    },
                    {
                        titulo: 'A suspeita',
                        direcao: 'Pedro Peregrino',
                        info: 'Depois de ser diagnosticada com Alzheimer, a '
                            + 'comissária da inteligência da Polícia Civil, '
                            + 'Lúcia (Gloria Pires) decide se aposentar o '
                            + 'quanto antes para cuidar de si e ficar mais '
                            + 'perto de sua família. Mas durante seu último '
                            + 'caso antes da aposentadoria ela descobre um '
                            + 'grande esquema e vira uma das principais '
                            + 'suspeitas na própria investigação.'
                    },
                    {
                        titulo: 'O EXTERMINADOR DO FUTURO: DESTINO SOMBRIO',
                        direcao: 'Tim Miller',
                        info: 'Na sexta aventura da saga Exterminador do Futuro'
                            + ', Arnold Schwarzenegger interpreta novamente o '
                            + 'papel icônico de T-800, enquanto Linda Hamilton'
                            + ' encarna mais uma vez Sarah Connor.'
                    }
                ],
                drama: [
                    {
                        titulo: 'Veneza',
                        direcao: 'Miguel Falabella',
                        info: 'Reencontrar o único homem que amou é o sonho de '
                            + 'Gringa (Carmen Maura), dona de um bordel no inte'
                            + 'rior do Brasil. Mesmo cega e muito doente, ela '
                            + 'insiste em realizar seu último desejo: ir até Ve'
                            + 'neza para pedir perdão ao amante que abandonou '
                            + 'décadas atrás. Para levá-la à cidade italiana, '
                            + 'Tonho (Eduardo Moscovis), Rita (Dira Paes) e as'
                            + ' outras moças que trabalham para Gringa idealiza'
                            + ' um fantástico plano com a ajuda de uma trupe'
                            + ' circense.'
                    }
                ],
                animacao: [
                    {
                        titulo: 'Angry Birds 2 o Filme',
                        direcao: ['Thurop Van Orman', 'John Rice'],
                        info: 'As novas aventuras dos passáros mais mal '
                            + 'humorados do planeta. Depois de descobrirem os '
                            + 'mistérios por trás da chegada dos porcos na ilha'
                            + ' em que viviam, Red, Chuck e Bomb se juntam em '
                            + 'novas confusões, cada vez mais irritados.'
                    }
                ],
                comedia: [
                    {
                        titulo: 'Ela disse, ele disse',
                        direcao: 'Cláudia Castro',
                        info: 'Baseado em um romance teen escrito pelo fenômeno'
                            + ' literário Talita Rebouças, o filme acompanha a'
                            + ' história de Rosa e Leo, dois adolescentes de 14'
                            + ' anos que namoram e estudam na mesma escola. Ele'
                            + 's tem crises, dilemas e pontos de vista'
                            + ' diferentes - mas se entendem com amor. '
                    },
                    {
                        titulo: 'Zumbilândia 2',
                        direcao: 'Ruben Fleischer',
                        info: 'Sequência de Zumbilândi. O enredo ainda é'
                            + ' desconhecido.'
                    }
                ],
                documentario: [
                    {
                        titulo: 'Inaudito',
                        direcao: 'Gregorio Gananian',
                        info: 'Nascido na China, Lanny Gordin fez carreira como'
                            + ' músico no Brasil, durante as décadas de 60 e 70'
                            + '.Neste período, trabalhou em discos e shows de '
                            + 'Gal Costa, Gilberto Gil, Caetano Veloso, Erasmo'
                            + ' Carlos, Jards Macalé e outros ícones da música '
                            + 'poupular brasileira. O ostracismo veio no final '
                            + 'da década de 70, associado ao desenvolvimento de'
                            + ' esquizofrenia. Aos 65 anos, Lanny relata sua '
                            + 'chegada ao país e revela seus pensamentos sobre '
                            + 'a vida e, especialmente, sua relação com a '
                            + 'música.'
                    }
                ]
            }
        },
        novembro: {
            lancamentos: 6,
            classificacao: {
                comedia: [
                    {
                        titulo: 'BONS MENINOS',
                        direcao: [' Lee Eisenberg', 'Gene Stupnitsky'],
                        info: 'Três meninos ainda inocentes, mas que estão'
                            + ' prestes a atingirem a adolescência, matam aula '
                            + 'em San Fernando Valley, na Califórinia, para '
                            + 'conseguir consertar um drone quebrado antes que '
                            + 'seus pais cheguem em casa. O que prometia ser um'
                            + ' dia comum transforma-se em uma grande aventura '
                            + 'repleta de perigos cômicos.'
                    }
                ],
                acao: [
                    {
                        titulo: 'As Panteras Reboot',
                        direcao: 'ELIZABETH BANKS',
                        info: 'O remake se passa após os filmes originais'
                            + ' , e terá foco na próxima geração de "Angels" '
                            + 'trabalhando para o misterioso Charlie. A '
                            + 'Townsend Agency agora é uma agência global '
                            + 'com equipes preparadas em todo o mundo, '
                            + 'fornecendo serviços de segurança e '
                            + 'inteligência para diversos clientes privados.'
                    },
                    {
                        titulo: 'Sonic O Filme',
                        direcao: 'Jeff Fowler',
                        info: 'Sonic, o porco-espinho azul mais famoso do '
                            + 'mundo, se junta com os seus amigos para '
                            + 'derrotar o terrível Doutor Eggman, um cienti'
                            + 'sta louco que planeja dominar o mundo, e o '
                            + 'Doutor Robotnik, responsável por aprisionar ani'
                            + 'mais inocentes em robôs. A sinopse oficial '
                            + 'ainda não foi divulgada.'
                    }
                ],
                biografia: [
                    {
                        titulo: 'Meu nome é Gal',
                        direcao: [' Dandara Ferreira', 'Lô Politi'],
                        info: 'A vida e carreira de uma das maiores artistas '
                            + 'brasileiras, Maria da Graça Costa Penna Burgos, '
                            + 'conhecida mundialmente como Gal Costa. A sinopse'
                            + ' oficial ainda não foi divulgada.'
                    }
                ],
                drama: [
                    {
                        titulo: 'OS SONÂMBULOS',
                        direcao: 'Tiago Mata Machado',
                        info: 'Um grupo de jovens incompreendidos vive suas vid'
                            + 'as de forma clandestina, escondendo suas '
                            + 'excentricidades aos olhos do mundo, que parece '
                            + 'estar prestes a acabar. Ligados uns aos outros '
                            + 'para garantirem as suas sobrevivências neste '
                            + 'ambiente hostil, eles compartilham contradições '
                            + 'que regem as suas vidas: é necessário amar a vid'
                            + 'a humana, ao mesmo tempo em que a própria '
                            + 'existência causa repulsa. '
                    },
                    {
                        titulo: 'NOITES DE ALFACE',
                        direcao: 'Zeca Ferreira',
                        info: 'Depois de presenciar a morte de sua esposa Ada '
                            + '(Marieta Severo), o rabugento Otto (Everaldo Pon'
                            + 'tes) volta a ter problemas para dormir sem o seu'
                            + ' remédio natural: um chá de alface que a mulher '
                            + 'preparava todas as noites. Sozinho e cansado, '
                            + 'sua única opção é observar o cotidiano de seus '
                            + 'peculiares vizinhos, mas logo sua participação '
                            + 'começa a ficar mais interativa do que o esperado'
                    }
                ]
            }
        },
        dezembro: {
            lancamentos: 4,
            classificacao: {
                animacao: [
                    {
                        titulo: 'É o bicho!',
                        direcao: [
                            'Tony Bancroft',
                            'Scott Christian Sava'
                        ],
                        info: 'Uma caixa mágica de biscoitos com formatos '
                            + 'de animais é utilizada por uma família para '
                            + 'tentar salvar o circo familiar das garras do'
                            + ' maléfico tio Horatio P. Huntington.'
                    }
                ],
                comedia: [
                    {
                        titulo: 'Maria do Caritó',
                        direcao: 'João Paulo Jabur',
                        info: 'Às vésperas de completar 50 anos, Maria do '
                            + 'Caritó (Lilia Cabral) vive em uma pequena cidade'
                            + ' do Nordeste em meio a simpatias para que, enfim'
                            + ', consiga se casar. Prometida a São Djalminha '
                            + 'assim que nasceu, devido a um parto difícil, ela'
                            + ' nunca encontrou um companheiro de verdade. '
                            + 'Entretanto, suas esperanças ressurgem com a che'
                            + 'gada de um circo, já que uma cartomante lhe diss'
                            + 'e que seu pretendente seria um homem de fora.'
                    },
                    {
                        titulo: 'Minha mãe é uma peça 3',
                        direcao: 'André Pellenz',
                        info: 'Depois do sucesso como apresentadora de TV, '
                            + 'Dona Hermínia (Paulo Gustavo) está de volta, ago'
                            + 'ra com o título de vovó. Os problemas e '
                            + 'reclamações, marca registrada de Hermínia, '
                            + 'continuam nesta nova fase de sua vida.'
                    }
                ],
                ficcaocientifica: [
                    {
                        titulo: 'STAR WARS: EPISÓDIO IX',
                        direcao: 'J.J. Abrams',
                        info: 'Nono filme da franquia Star Wars'
                    }
                ]
            }
        }
    }
};

const chv = Object.keys(cinema.meses);
console.log(chv); // ["janeiro", "fevereiro", "marco", "abril",
// "maio", "junho", "julho", "agosto",
// "setembro", "outubro", "novembro", "dezembro"]

const teste1 = cinema.meses.janeiro.classificacao.acao;
// retorna os filmes de ação de janeiro e suas informações
console.log(teste1);

const test2 = cinema.meses.outubro.classificacao.acao[0].titulo;
console.log(test2); // Coringa


const teste3 = cinema.meses.agosto.classificacao.fantasia[1].titulo;
console.log(teste3); // Artemis Fowl

const teste4 = cinema.meses.agosto.classificacao.fantasia[1].direcao;
console.log(teste4); // Kenneth Branagh

const teste5 = cinema.meses.agosto.classificacao.fantasia[1].info;
console.log(teste5); // informação a respeito do filme

const teste6 = cinema.meses.janeiro.lancamentos;
console.log(teste6); // 14
