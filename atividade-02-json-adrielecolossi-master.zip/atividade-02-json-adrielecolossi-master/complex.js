// complex.js (0.5 pts)
console.log('complex.js');

// rational.js

function complex(real, imaginario) {
    return {
        real: real,
        imaginario: imaginario,
        soma: function(outrocomplexo) {
            return complex(this.real + outrocomplexo.real,
                this.imaginario + outrocomplexo.imaginario);
        },
        subtracao: function(outrocomplexo) {
            // const real;
            // const imaginario;
            const real = this.real > outrocomplexo.real ?
                (this.real - outrocomplexo.real)
                : -(outrocomplexo.real - this.real);
            const imaginario = this.imaginario > outrocomplexo.imaginario ?
                (this.imaginario - outrocomplexo.imaginario) :
                -(outrocomplexo.imaginario - this.imaginario);
            return complex(real, imaginario);
        },
        conjugado: function() {
            return complex(this.real, -(this.imaginario));
        }
    };
}
const r1 = complex(2, 3);
console.log(r1.real === 2);
console.log(r1.imaginario === 3);
const r2 = complex(3, 5);
console.log(r2.real === 3);
console.log(r2.imaginario === 5);
const r3 = r1.soma(r2);
console.log(r3.real === 5);
console.log(r3.imaginario === 8);

const r4 = (complex(3, -5).soma(complex(1, 3)));
console.log(r4.real === 4);
console.log(r4.imaginario === -2);
const r5 = r1.subtracao(r2);
console.log(r5.real === -1);
console.log(r5.imaginario === -2);

const r6 = r1.subtracao(r3);
console.log(r6.real === -3);
console.log(r6.imaginario === -5);

const r7 = r3.subtracao(r1);
console.log(r7.real === 3);
console.log(r7.imaginario === 5);

const r8 = r1.conjugado();
console.log(r8.real === 2);
console.log(r8.imaginario === -3);

const r9 = (complex(1, -3)).conjugado();
console.log(r9.real === 1);
console.log(r9.imaginario === 3);

console.log(((complex(4, 5)).conjugado()).imaginario === -5);
console.log(((complex(-4, 5)).conjugado()).real === -4);
