// netflix.js // 0.5 pts
console.log('netflix.js');

const Netflix = {
    series: [
        {
            title: 'Sherlock',
            descricao: 'O dr. John Watson precisa de um lugar para morar'
                + 'em Londres. Ele é apresentado ao detetive Sherlock Holmes'
                + 'e os dois acabam desenvolvendo uma parceria intrigante, na'
                + 'qual a dupla vagará pela capital inglesa solucionando'
                + ' assassinatos e outros crimes brutais.'
                + ' Tudo isso em pleno século XXI.',
            criadores: 'Martin Gatiss',
            classificacao: 14,
            ano: 2010,
            seasons: [
                {
                    episodes: [
                        {
                            title: 'Um estudo em rosa',
                            sinopse: 'Uma mulher de rosa é o quarto óbito de '
                                + 'uma série de suicídios teoricamente não' +
                                'relacionados, mas Sherlock deduz' +
                                'que há um assassino em cena',
                            duracao: 88
                        },
                        {
                            title: 'O banqueiro cego',
                            sinopse: 'A nova vida de Watson como companheiro de'
                                + ' apartamento de Sherlock Holmes é muito '
                                + 'agitada. Até uma uma ida ao banco com '
                                + 'Sherlock deixa o doutor apreensivo.',
                            duracao: 88
                        },
                        {
                            title: 'O grande jogo',
                            sinopse: 'Desesperado com a engenhosidade dos'
                                + ' criminosos londrinos, Sherlock aceita o que'
                                + ' parece ser um caso comum e descobre que um'
                                + ' gênio do crime está agindo',
                            duracao: 88
                        }
                    ]
                },
                {
                    episodes: [
                        {
                            title: 'Um escândao em Belgrávia',
                            sinopse: 'Um escândalo real coloca Sherlock'
                                + ' em meio a um duelo de inteligência.',
                            duracao: 89
                        },
                        {
                            title: 'Os cães de Baskerville',
                            sinopse: 'Sherlock viaja para Dartmoor para revelar'
                                + ' o mistério de um cachorro vindo do'
                                + ' inferno.',
                            duracao: 88
                        },
                        {
                            title: 'A queda de Reinchenbach',
                            sinopse: 'Sherlock começa a bataha com Moriarty,'
                                + ' seu maior adversário',
                            duracao: 88
                        }
                    ]
                },
                {
                    episodes: [
                        {
                            title: 'O caixão vazio',
                            sinopse: 'Dois anos após a “morte” de Sherlock, '
                                + 'Watson está seguindo com a vida. Mas quando '
                                + 'Londres é ameaçada por um ataque terrorista,'
                                + ' Sherlock decide que é hora de retornar.',
                            duracao: 86
                        },
                        {
                            title: 'O sinal dos três',
                            sinopse: 'Sherlock enfrenta seu maior desafio até '
                                + 'agora - fazer um discurso como padrinho no '
                                + 'casamento do John! Mas nem tudo é o que'
                                + ' parece.',
                            duracao: 88
                        },
                        {
                            title: 'Seu último juramento',
                            sinopse: 'Um caso de cartas roubadas leva Sherlock'
                                + ' Holmes a entrar em conflito com o poderoso'
                                + ' Charles Augustus Magnussen, o Napoleão'
                                + ' da chantagem.',
                            duracao: 89
                        },
                        {
                            title: 'A abominável noiva',
                            sinopse: 'Em 1895, Holmes e Watson investigam a '
                                + 'aparição de um vulto com um vestido de noiva'
                                + ', supostamente o fantasma de uma vítima'
                                + ' suicida.',
                            duracao: 89
                        },
                    ]
                },
                {
                    episodes: [
                        {
                            title: 'As seis Thatchers',
                            sinopse: 'A Scotland Yard apresenta um caso'
                                + ' curioso a Sherlock que envolve o filho de '
                                + 'um ministro e estátuas quebradas da falecida'
                                + ' primeira-ministra Margaret Thatcher.',
                            duracao: 88
                        },
                        {
                            title: 'O detetive mentiroso',
                            sinopse: 'Watson enfrenta uma grande tragédia. '
                                + 'Enquanto isso, Sherlock confronta seu advers'
                                + 'ário mais astuto até então: um filantropo '
                                + 'com um segredo sombrio.',
                            duracao: 89
                        },
                        {
                            title: 'O problema final',
                            sinopse: 'Um segredo de família traz à tona lemb'
                                + 'ranças reprimidas que Sherlock nem sabia que'
                                + ' tinha, levando a um jogo mortal e a um reen'
                                + 'contro com um velho inimigo.',
                            duracao: 89
                        },
                    ]
                }
            ]
        },
        {
            title: 'Desventuras em série',
            descricao: 'Más notícias chegam às crianças da família.'
                + 'Beaudelaire Um incêndio destruiu a mansão onde eles'
                + ' viviam e ainda provocou a morte de seus pais. Órfãos'
                + ' e sem idade suficiente para cuidarem de si mesmos, Klaus,'
                + ' Violet e a pequena Sunny vão viver com um tio, o ganancioso'
                + ' e cruel Conde Olaf.',
            criadores: 'Barry Sonnenfeld',
            classificacao: 12,
            ano: 2017,
            seasons: [
                {
                    episodes: [
                        {
                            title: 'Mau Começo: Volume 1',
                            sinopse: 'A terrível história dos irmãos Baudela '
                                + 'ire começa com um narrador irônico, um' +
                                'incêndio e a chegada de um parente distante.',
                            duracao: 49
                        },
                        {
                            title: 'Mau Começo: Volume 2',
                            sinopse: 'Enquanto a secretária do Sr. Poe faz '
                                + 'hora extra, o Conde Olaf coloca Violet e '
                                + 'Klaus para atuar numa peça de teatro que '
                                + 'terá consequências alarmantes.',
                            duracao: 64
                        },
                        {
                            title: 'A Sala dos Répteis: Volume 1',
                            sinopse: 'Depois que as crianças se mudam para a '
                                + 'casa do Dr. Montgomery, um famoso especiali'
                                + 'sta no comportamento de répteis, o novo guar'
                                + 'dião contrata um assistente bem conhecido.',
                            duracao: 48
                        },
                        {
                            title: 'A Sala dos Répteis: Volume 2',
                            sinopse: 'Klaus e Violet suspeitam do Conde Olaf'
                                + ' e seus malvados seguidores quando um cadáv'
                                + 'er aparece na sala dos répteis. Sunny exami'
                                + 'na o interior de uma mala.',
                            duracao: 48
                        },
                        {
                            title: 'O lago das Sanguessugas- Volume 1',
                            sinopse: 'Os órfãos chegam ao Lago Lacrimoso para'
                                + ' conhecer a Tia Josephine. Lá descobrem que '
                                + 'a tia que ficou viúva recentemente é uma pro'
                                + 'fessora severa e atormentada pelo passado.',
                            duracao: 42
                        },
                        {
                            title: 'O lago das Sanguessugas- Volume 2',
                            sinopse: 'Klaus e Violet procuram pistas num bilh'
                                + 'ete suspeito que transfere a custódia das cr'
                                + 'ianças para o Capitão Sham, um charlatão '
                                + 'obviamente ligado ao Conde Olaf.',
                            duracao: 53
                        },
                        {
                            title: 'Serraria Baixo-Astral- Volume 1',
                            sinopse: 'As crianças chegam a um novo destino'
                                + ' e descobrem acusações perturbadoras sobre'
                                + ' seus pais. O Conde Olaf tenta conquistar'
                                + ' uma antiga paixão.',
                            duracao: 44
                        },
                        {
                            title: 'Serraria Baixo-Astral- Volume 2',
                            sinopse: 'Depois de fazer uma consulta com um'
                                + ' optometrista chamado Dr. Orwell, Klaus'
                                + ' passa a agir de modo muito estranho.'
                                + 'Enquanto isso Violet tenta limpar o'
                                + ' nome dos pais.',
                            duracao: 47
                        }
                    ]
                },
                {
                    episodes: [
                        {
                            title: 'Inferno no Colégio Interno: Volume 1',
                            sinopse: 'No colégio interno, os Baudelaires'
                                + ' conhecem misteriosos irmãos com a vida'
                                + ' quase tão trágica quanto a deles.',
                            duracao: 46
                        },
                        {
                            title: 'Inferno no Colégio Interno: Volume 2',
                            sinopse: 'Enquanto os Quagmires seguem na busca,'
                                + ' os Baudelaires dão duro para conciliar os '
                                + 'estudos com uma extenuante rotina de '
                                + 'exercícios – cortesia do Conde Olaf.',
                            duracao: 52
                        },
                        {
                            title: 'O Elevador Ersatz: Volume 1',
                            sinopse: 'Violet, Klaus e Sunny ganham novos'
                                + ' guardiões em um estiloso arranha-céu '
                                + 'sem elevador. Jacques Snicket treina'
                                + ' uma recruta.',
                            duracao: 52
                        },
                        {
                            title: 'O Elevador Ersatz: Volume 2',
                            sinopse: 'Os Baudelaires encontram seus amigos...'
                                + 'mas não por muito tempo! Disfarçado, Conde'
                                + ' Olaf conduz um leilão',
                            duracao: 41
                        },
                        {
                            title: 'A Cidade Sinistra dos Corvos: Volume 1',
                            sinopse: 'O Sr. Poe leva os Baudelaires a'
                                + ' um vilarejo repleto de aves e clima do'
                                + ' velho oeste. Jacques e Olívia continuam'
                                + ' a busca pelos Quagmires',
                            duracao: 48
                        },
                        {
                            title: 'A Cidade Sinistra dos Corvos: Volume 2',
                            sinopse: 'Os órfãos são suspeitos de um assassinato'
                                + ' terrível, mas o tempo que passam atrás das'
                                + ' grades leva a uma importante descoberta.',
                            duracao: 41
                        },
                        {
                            title: 'O Hospital Hostil: Volume 1',
                            sinopse: 'Foragidos, os Baudelaires vão parar em'
                                + ' um hospital terrível com uma biblioteca'
                                + ' gigantesca. Será que ela guarda as resp'
                                + 'ostas para todas as suas perguntas?',
                            duracao: 44
                        },
                        {
                            title: 'O Hospital Hostil: Volume 2',
                            sinopse: 'Klaus e Sunny vasculham o decrépito '
                                + 'hospital em busca de Violet, mantida '
                                + 'prisioneira sob os "cuidados" do Conde'
                                + 'Olaf.',
                            duracao: 40
                        },
                        {
                            title: 'O Espetáculo Carnívoro: Volume 1',
                            sinopse: 'Venha conhecer o mais aterrorizante'
                                + ' circo do mundo, um lugar onde mistérios'
                                + ' surpreendentes- e um rosto familiar- '
                                + 'estão à espera',
                            duracao: 46
                        },
                        {
                            title: 'O Espetáculo Carnívoro: Volume 2',
                            sinopse: 'Com seu grotesco disfarce do circo, '
                                + 'os Baudelaires se preparam para enfrentar '
                                + 'um fado terrível. Será que, pelo menos '
                                + 'dessa vez, eles terão alguma sorte?',
                            duracao: 42
                        }
                    ]
                },
                {
                    episodes: [
                        {
                            title: 'O Escorregador de Gelo: Volume 1',
                            sinopse: 'O conde Olaf segue para o quartel-'
                                + 'general da CSC com Sunny. Enquanto isso, '
                                + 'Klaus e Violet estão exatamente onde os '
                                + 'deixamos: avançando em direção à beira '
                                + 'do penhasco.',
                            duracao: 43
                        },
                        {
                            title: 'O Escorregador de Gelo: Volume 2',
                            sinopse: 'Sunny envia sinal do acampamento do'
                                + ' conde Olaf, onde uma dupla sinistra despe'
                                + 'rta antigos receios. Uma pista no QG da CSC '
                                + 'aponta o caminho para uma reunião fatídica.',
                            duracao: 44
                        },
                        {
                            title: 'A Gruta Gorgônea: Volume 1',
                            sinopse: 'A jovem capitã de um submarino com '
                                + 'ligações com a CSC revela que ela está '
                                + 'procurando o açucareiro. Também é o caso '
                                + 'de Esmé Squalor, que tenta encontrá-lo'
                                + ' primeiro.',
                            duracao: 44
                        },
                        {
                            title: 'A Gruta Gorgônea: Volume 2',
                            sinopse: 'Com o destino de Sunny por um fio, Violet'
                                + ' e Klaus correm para encontrar um antídoto'
                                + ' para salvar vidas e descobrir a localização'
                                + ' do Último Local Seguro.',
                            duracao: 36
                        },
                        {
                            title: 'O Penúltimo Perigo: Volume 1',
                            sinopse: 'Várias festas convergem no Hotel Desenla'
                                + 'ce, onde o misterioso "J.S." chamou a CSC –'
                                + ' e as coisas nem sempre são o que parecem.',
                            duracao: 55
                        },
                        {
                            title: 'O Penúltimo Perigo: Volume 2',
                            sinopse: 'Quando o conde Olaf vai a julgamento'
                                + ' no saguão do hotel, grandes segredos são '
                                + 'reveados. Os Baudelaire são os primeiros a '
                                + 'testemunhar. Mas a justiça será feita?',
                            duracao: 52
                        },
                        {
                            title: 'O Fim',
                            sinopse: 'O último capítulo leva os órfãos a uma'
                                + ' ilha deserta: um lugar de vidas perdidas,'
                                + ' histórias antigas e novos começos.'
                                + ' Tudo acaba aqui.',
                            duracao: 52
                        }
                    ]
                }
            ]
        }
    ]
};

// title of the first TV serie
console.log(Netflix['series'][0]['title']); // any title
// there is a first season with at least one episode, must print true
console.log(Netflix['series'][0]['seasons'][0]['episodes'].length > 0);
console.log(Netflix[
    'series'][0][
    'seasons'][0][
    'episodes'][0][
    'title'] !== undefined); // must be true

// Add more test cases which should cover
// the assessment specification:

console.log(Netflix['series'][1][
    'seasons'][0]['episodes'][0]['title'] ==='Mau Começo: Volume 1');
console.log(Netflix['series'][1]['seasons'][2]['episodes'][6]['duracao']===52);
console.log(Netflix['series'][1]['ano']===2017);
console.log(Netflix['series'][0]['classificacao']===14);
